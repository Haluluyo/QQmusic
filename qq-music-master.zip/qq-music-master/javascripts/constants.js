export const RECOMMEND_URL = 'https://qq-music-api.now.sh'
export const TOPLIST_URL = 'https://qq-music-api.now.sh/top'
export const SEARCH_URL = 'https://qq-music-api.now.sh/search'
export const LYRICS_URL = 'https://qq-music-api.now.sh/lyrics'